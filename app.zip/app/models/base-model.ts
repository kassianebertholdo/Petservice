
export default abstract class BaseModel {
    id: string
    status: string
}